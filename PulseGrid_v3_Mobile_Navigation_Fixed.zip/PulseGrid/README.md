# PulseGrid v3 — Multi-View AI Emergency Coordinator

Open `index.html` in a modern browser.

## What is new
- Real working sidebar navigation
- Command Center
- Live Incidents page with filtering + incident analysis
- Hospitals page with capacity, travel, handoff, capability and AI suitability
- Response Units page with fleet status + proactive coverage recommendation
- Communications page with incident timeline and human approval actions
- Reports page with simulated benchmark analytics
- Shared demo data across the pages
- Location-aware command map via browser Geolocation
- Interactive Leaflet + OpenStreetMap map

## Important
The analytics values are illustrative simulated benchmark results for a school competition prototype. They are not claims of real-world emergency performance.

Geolocation generally requires HTTPS or localhost in browsers. The app still runs without permission and falls back to its demo map.

Real deployment would require verified operational data, clinical/dispatch validation, cybersecurity, privacy controls, auditing, safety evaluation and human oversight.
